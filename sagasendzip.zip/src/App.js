import "./App.css";
import React, { Suspense, lazy } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./Components/Login";
import Register from "./Components/Register";
import Header from "./Header";
import Dashboard from "./Components/Dashboard";
import Enquiries from "./Components/Dashboard/Enquiries";
import FAQ from "./Components/Dashboard/FAQ";
import Profile from "./Components/Dashboard/Profile";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
// const Dashboard = lazy(() => import("./Components/Dashboard"));

function App() {
  let message = localStorage.getItem("Token");
  console.log("llllll", message);
  return (
    <div className="App">
      <ToastContainer />
      <BrowserRouter>
        {message ? (
          <>
            <Routes>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/enquiries" element={<Enquiries />} />
              <Route path="/faq" element={<FAQ />} />
              <Route path="/profile" element={<Profile />} />
            </Routes>
          </>
        ) : (
          <>
            <Routes>
              <Route path="/" element={<Register />} />
              <Route path="/login" element={<Login />} />
              <Route path="/faq" element={<FAQ />} />
              <Route path="/enquiries" element={<Enquiries />} />
            </Routes>
          </>
        )}
      </BrowserRouter>
    </div>
  );
}

export default App;
