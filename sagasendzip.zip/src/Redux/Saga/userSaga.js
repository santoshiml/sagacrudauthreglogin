import {
  REGISTER_REQUEST,
  REGISTER_ERROR,
  LOGIN_REQUEST,
  LOGIN_ERROR,
  REGISTER_SUCCESS,
  LOGIN_SUCCESS,
  DELETE_REQEST,
  DELETE_SUCCESS,
  DELETE_ERROR,
} from "../Action/actionType";
import { call, put, takeEvery } from "redux-saga/effects";

function* fetchUser(action) {
  try {
    yield put({ type: REGISTER_SUCCESS, user: action.payload });
  }catch (e) {
    yield put({ type: REGISTER_ERROR, error: e.message });
  }
}

function* loginUser(action) {
  try {
    
    yield put({ type: LOGIN_SUCCESS, user: action.payload });
  } catch (e) {
    yield put({ type: LOGIN_ERROR, error: e.message });
  }
}

function* deleteUser(action) {
  try {
    yield put({ type: DELETE_SUCCESS, user: action.payload });
  } catch (e) {
    yield put({ type: DELETE_ERROR, error: e.message });
  }
}

function* userSaga() {
  yield takeEvery(REGISTER_REQUEST, fetchUser);
  yield takeEvery(LOGIN_REQUEST, loginUser);
  yield takeEvery(DELETE_REQEST, deleteUser);
}

export default userSaga;
