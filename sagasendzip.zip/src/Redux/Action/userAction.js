import {
  REGISTER_REQUEST,
  LOGIN_REQUEST,
  DELETE_REQEST, 
} from "./actionType";

export const Register = (data) => {
  // console.log('useraction reg', data)
  return {
    type: REGISTER_REQUEST,
    payload: data,
  };
};

export const Login = (data) => {
  // console.log('userLogindata', data)
  return {
    type: LOGIN_REQUEST,
    payload: data,
  };
};


