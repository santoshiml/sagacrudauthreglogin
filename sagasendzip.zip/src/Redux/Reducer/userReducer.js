import {
  REGISTER_ERROR,
  REGISTER_SUCCESS,
  LOGIN_REQUEST,
  LOGIN_SUCCESS,
  LOGIN_ERROR,
  DELETE_REQEST,
  DELETE_SUCCESS,
  DELETE_ERROR,
} from "../Action/actionType";

const initState = {
  users: [],
  error: [],
};

const userReducer = (state = initState, action) => {
  console.log("111", action);

  switch (action.type){
    case REGISTER_SUCCESS:
      let userinfo = state.users.concat(action.user)
      console.log(userinfo)
      localStorage.setItem("userData",JSON.stringify(userinfo));
      return {
        ...state,
        users: state.users.concat(action.user)
      };

    case REGISTER_ERROR:
      return {
        ...state,
        error: action.payload,
      };
      break;

    case LOGIN_REQUEST:
      let userlistget = localStorage.getItem("userData");
      let allUser = JSON.parse(userlistget);
      {
        allUser.map((data) => {
          if (
            action.payload.email == data.email &&
            action.payload.password == data.password
          ) {
            let token = "21sdf2sdf15d1SDfsdf1654";
            localStorage.setItem("Token", JSON.stringify(token));
          }
        });
      }

      return {
        ...state,
        users: action.user,
      };
      
    case LOGIN_SUCCESS:
      return {
        ...state,
        users: action.user,
      };
    case LOGIN_ERROR:
      return {
        ...state,
        error: action.error,
      };
      

    default:
      return state;
  }
};

export default userReducer;
