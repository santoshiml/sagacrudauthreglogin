import React, { useEffect } from "react";
import Modal from "react-modal/lib/components/Modal";
import { useState } from "react";

const customStyles = {
  content: {
    top: "50%",
    left: "50%",
    right: "auto",
    bottom: "auto",
    marginRight: "-50%",
    transform: "translate(-50%, -50%)",
  },
};
const Postupdate = (props) => {
  const [firstName, setfirstName] = useState();
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const [number, setNumber]=useState();
  const [role, setRole]= useState();
 

  const handleChange1 = (e) => {
    console.log("handlechange1", e.target.value);
    setfirstName(e.target.value);
  };

  const handleChange2 = (e) => {
    console.log("handlechange2", e.target.value);
    setEmail(e.target.value);
  };

  const handleChange3 = (e) => {
    console.log("handlechange3", e.target.value);
    setNumber(e.target.value);
  };


  const handleChange4 = (e) => {
    console.log("handlechange4", e.target.value);
    setRole(e.target.value);
  };

  useEffect(() => {
    setfirstName(props.firstName);
    setPassword(props.password);
    setNumber(props.number);
    setRole(props.role);
  }, []);

  return (
    <div>
      <Modal
        isOpen={props.isVisible}
        // onRequestClose={this.props.closeModal}
        ariaHideApp={false}
        style={customStyles}
        contentLabel="Example Modal"
      >
        <input
          type="text"
          placeholder="firstName"
          value={firstName}
          onChange={handleChange1}
        /><br/><br/>


         <input
          type="number"
          placeholder="Enter Number"
          value={number}
          onChange={handleChange3}
        /><br/><br/>

        <input
          type="role"
          placeholder="Enter Role"
          value={role}
          onChange={handleChange4}
        /><br/><br/>

        <button onClick={() => props.updatePost(props.email, firstName, password, number, role )}>
          {" "}
          Update!!!{" "}
        </button>
        <button onClick={props.closeModal}>close</button><br/><br/>
      </Modal>
    </div>
  );
};

export default Postupdate;