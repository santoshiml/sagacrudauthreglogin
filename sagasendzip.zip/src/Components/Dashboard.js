import React, { useState, useEffect, Suspense, lazy } from "react";
import { useNavigate } from "react-router";
import Sidebar from "./Sidebar";
import { useDispatch, useSelector } from "react-redux";
import "bootstrap/dist/css/bootstrap.css";
import Table from "react-bootstrap/Table";
import DeleteIcon from "@material-ui/icons/Delete";
import EditIcon from "@material-ui/icons/Edit";
import SearchIcon from "@material-ui/icons/Search";
import Modal from "./Modal";
import { toast } from "react-toastify";
import "bootstrap/dist/css/bootstrap.min.css";


const Lazyload = React.lazy(() => import("./Dashboard/Lazyload"));

const Dashboard = () => {
  const navigate = useNavigate();
  const [search, setNewsearch] = useState();
  const dispatch = useDispatch();
  const [isVisible, setIsVisible] = useState(false);
  const [firstName, setfirstName] = useState();
  const [email, setEmail] = useState();
  const[password, setPassword] = useState();
  const[number, setNumber] = useState();
  const [role, setRole] = useState();



  let userlist = localStorage.getItem("userData");
  let allUser = JSON.parse(userlist);
  console.log("22222", allUser);
  const filtered = !search
    ? allUser
    : allUser.filter((data) => data.firstName.toLowerCase().includes(search));

  const handleSearch = (e) => {
    e.preventDefault();
    setNewsearch(e.target.value);
  };

  const remove = (email) => {
    const datainfo = JSON.parse(localStorage.getItem("userData"))
    console.log('data', datainfo)
    const users = datainfo.filter((item)=>item.email!=email)
    console.log('newuser', users)
    if(users){
      alert("Are you sure want to delete!")
    }
    toast.success(`Post deleted Successfully!`);

    localStorage.setItem("userData",JSON.stringify(users));
    
    window.location.reload(true); 

  };


  const CustomComponent = lazy(
    () =>
      new Promise((resolve, reject) =>
        setTimeout(() => resolve(import("./Dashboard/Lazyload")), 1000)
      )
  );


  const edit =(firstName, email, password, number, role) =>{
    alert("Are you sure you want to update!")
    setIsVisible(true);
    setfirstName(firstName);
    setEmail(email);
    setPassword(password);
    setNumber(number);
    setRole(role);
  }

  const updatePost = (firstName, email, password, number, role) => {
    isVisible && setIsVisible(false);
    const updatedatainfo = JSON.parse(localStorage.getItem("userData"));
    
    let posts = updatedatainfo;
    console.log('post', updatedatainfo)

    posts.map((post) =>{
      if(post.email===email){
        post.firstName=firstName;
        post.password=password;
        post.number=number;
        post.role=role;        
      }
    });
    setIsVisible('');
    localStorage.setItem("userData", JSON.stringify(updatedatainfo));
  };


  const closeModal = () => {
    console.log("Modal Closed");
    setIsVisible(false);
  };


  return (
    <div>
      <Sidebar />
      <br />
      <Suspense fallback={<div>Loading...</div>} minDuration={2000}>
        <CustomComponent />
      </Suspense>
      <center>
        <input
          type="text"
          value={search}
          onChange={handleSearch}
          placeholder="Search for..."
        />
        <SearchIcon />
      </center>
      <br />

      {isVisible && (
        <Modal
          isVisible={isVisible}
          closeModal={closeModal}        
          firstName={firstName}
          email={email}
          password={password}
          number={number}
          role={role}      
          updatePost={updatePost}
        />
      )}


      <Table stripped bordered hover size="sm">
        <thead>
          <tr>
            <th>Id</th>
            <th>UserName</th>
           
            <th>Email</th>
            <th>Conatct No.</th>
            <th>RoleType</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map((user, id = 1) => {
            return (
              <>
                <tr>
                  <td key={id}>{id + 1}</td>
                  <td>{user.firstName}</td>               
                  <td>{user.email}</td>
                  <td>{user.number}</td>
                  <td>{user.role}</td>
                  <td>
                    <EditIcon onClick={() =>edit(user.firstName,user.email,user.password, user.number, user.role)}/>
                    <DeleteIcon onClick={() => remove(user.email)} />
                  </td>
                </tr>
              </>
            );
          })}
        </tbody>
      </Table>
    </div>
  );
};

export default Dashboard;
