import React from 'react';
import Sidebar from '../Sidebar';

export default function Enquiries() {
  return (
    <div>
        <Sidebar />


    </div>
  )
}
