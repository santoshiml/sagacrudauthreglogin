import React from 'react'

export default function Lazyload() {
  return (
    <div>
      <h4>Welcome to Dashboard!</h4>
    </div>
  )
}
