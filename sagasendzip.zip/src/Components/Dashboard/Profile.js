import React from 'react';
import Sidebar from '../Sidebar';

export default function Profile() {
  return (
    <div>
        <Sidebar />
    </div>
  )
}
