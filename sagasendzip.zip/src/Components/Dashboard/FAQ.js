import React from 'react';
import Sidebar from '../Sidebar';

export default function FAQ() {
  return (
    <div>
        <Sidebar />
    </div>
  )
}
