import React from "react";
import { Link } from "react-router-dom";
import { useDispatch } from "react-redux";
import { Register } from "../Redux/Action/userAction";
import { useForm } from "react-hook-form";

const Register1 = () => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm();

  const dispatch = useDispatch();
 
  const RegisterUser = (data) => {
    console.log('dddd', data)
    reset(); 
    let userlistget = JSON.parse(localStorage.getItem("userData")) || [],
       isExist = userlistget.findIndex((obj) => {
          return obj.email === data.email
        }) != -1;
    if (isExist) {
      alert("Email Already be taken")
    } else {
        dispatch(Register(data))
    }
  };

  return (
    <div className="regForm">
      <form onSubmit={handleSubmit(RegisterUser)}>
        <h4>
          <center>Registration Form!</center>
        </h4>

        <div className="field-form">
          <input
            type="text"
            placeholder="Enter First Name"
            {...register("firstName", {
              required: true,
            })}
          />
          {errors?.firstName?.type === "required" && (
            <p className="error">First Name required*</p>
          )}
        </div>
        <br />

        <div className="field-form">
          <input
            type="email"
            placeholder="Enter Email"
            {...register("email", {
              required: true,
            })}
          />
          {errors?.email?.type === "required" && (
            <p className="error">Email required*</p>
          )}
        </div>
        <br />

        <div className="field-form">
          <input
            type="password"
            placeholder="Enter Password"
            {...register("password", {
              required: true,
            })}
          />
          {errors?.password?.type === "required" && (
            <p className="error">Password required*</p>
          )}
        </div>

        <br />

        <div className="field-form">
          <input
            type="text"
            placeholder="Enter Phone Number"
            {...register("number", {
              required: true,
            })}
          />
          {errors?.number?.type === "required" && (
            <p className="error">Phone number is*</p>
          )}
        </div>
        <br />

        <label>Role-type:</label>
        <input type="radio" name="role" value="user" {...register("role")} />
        <label>User</label>
        <input type="radio" name="role" value="admin" {...register("role")} />
        <label>Admin</label>

        <div className="field-form">
          <span>Have an account?</span>
          <Link to="/login"> Login</Link>{" "}
          <button className="regButton">Register</button>
        </div>
      </form>
    </div>
  );
};

export default Register1;
